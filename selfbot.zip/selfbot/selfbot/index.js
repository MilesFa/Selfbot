const { Client } = require("discord.js-selfbot-v13");

const client = new Client({
    checkUpdate: false,
    syncStatus: false,
    autoRedeemNitro: false,
    patchVoice: false
});

const prefix = "!";
console.log("Connecting to self bot...");

const USER_TOKEN = "YOUR_TOKEN_HERE";

// Storage for automatic messages
let autoResponders = new Map();
let autoReactEnabled = false;
let autoReactEmoji = "👍";

client.login(USER_TOKEN)
    .then(() => {
        console.log("Connected to self bot!");
        console.log(`Username: ${client.user.tag}`);
        console.log(`Command prefix: ${prefix}`);
        console.log("Type !help to see available commands");
    })
    .catch((error) => {
        console.log("Could not connect to self bot - " + error);
        console.log("Check if your token is valid and you have internet connection");
    });

client.on("ready", () => {
    console.log(`Logged in as ${client.user.tag}`);
    client.user.setStatus('online');
});

client.on("messageCreate", async (message) => {
    // Auto-responder
    if (message.author.id !== client.user.id && autoResponders.has(message.channel.id)) {
        const response = autoResponders.get(message.channel.id);
        await message.channel.send(response);
    }

    // Auto-react
    if (autoReactEnabled && message.author.id !== client.user.id) {
        await message.react(autoReactEmoji).catch(console.error);
    }

    if (message.author.id !== client.user.id) return;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    try {
        switch (command) {
            case "ping":
                const msg = await message.channel.send("Calculating ping...");
                msg.edit(`🏓 Pong! Latency: ${msg.createdTimestamp - message.createdTimestamp}ms`);
                break;

            case "clear":
                const amount = parseInt(args[0]) || 10;
                const messages = await message.channel.messages.fetch({ limit: amount });
                const userMessages = messages.filter(m => m.author.id === client.user.id);
                for (const msg of userMessages.values()) {
                    await msg.delete().catch(console.error);
                }
                message.channel.send(`✅ Deleted ${userMessages.size} messages`);
                break;

            case "edit":
                if (args.length < 2) {
                    message.channel.send("❌ Usage: !edit [number of messages] [new text]");
                    return;
                }
                const editCount = parseInt(args[0]);
                const newText = args.slice(1).join(" ");
                const msgsToEdit = await message.channel.messages.fetch({ limit: 100 });
                const userMsgs = msgsToEdit.filter(m => m.author.id === client.user.id).first(editCount);
                for (const msg of userMsgs) {
                    await msg.edit(newText).catch(console.error);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
                message.channel.send(`✅ Edited ${userMsgs.length} messages`);
                break;

            case "autoreply":
                if (!args[0]) {
                    autoResponders.delete(message.channel.id);
                    message.channel.send("✅ Auto-reply disabled for this channel");
                } else {
                    const response = args.join(" ");
                    autoResponders.set(message.channel.id, response);
                    message.channel.send(`✅ Auto-reply set to: "${response}"`);
                }
                break;

            case "autoreact":
                if (!args[0]) {
                    autoReactEnabled = !autoReactEnabled;
                    message.channel.send(`✅ Auto-react ${autoReactEnabled ? "enabled" : "disabled"}`);
                } else {
                    autoReactEmoji = args[0];
                    autoReactEnabled = true;
                    message.channel.send(`✅ Auto-react set to ${autoReactEmoji}`);
                }
                break;

            case "dm":
                if (args.length < 2) {
                    message.channel.send("❌ Usage: !dm [@user] [message]");
                    return;
                }
                const targetDmUser = message.mentions.users.first();
                if (!targetDmUser) {
                    message.channel.send("❌ User not found");
                    return;
                }
                const dmMessage = args.slice(1).join(" ");
                await targetDmUser.send(dmMessage);
                message.channel.send(`✅ Message sent to ${targetDmUser.tag}`);
                break;

            case "ghostping":
                if (!message.mentions.users.size) {
                    message.channel.send("❌ Mention at least one user");
                    return;
                }
                await message.delete();
                break;

            case "quote":
                if (!args[0]) {
                    message.channel.send("❌ Usage: !quote [message ID]");
                    return;
                }
                try {
                    const quotedMsg = await message.channel.messages.fetch(args[0]);
                    message.channel.send(`> ${quotedMsg.content}\n- ${quotedMsg.author.tag}`);
                } catch {
                    message.channel.send("❌ Message not found");
                }
                break;

            case "spam":
                if (args.length < 2) {
                    message.channel.send("❌ Usage: !spam [number] [message]");
                    return;
                }
                const spamCount = parseInt(args[0]);
                if (spamCount > 20) {
                    message.channel.send("❌ Maximum 20 messages allowed");
                    return;
                }
                const spamText = args.slice(1).join(" ");
                for (let i = 0; i < spamCount; i++) {
                    await message.channel.send(spamText);
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
                break;

            case "massdm":
                if (!args[0]) {
                    message.channel.send("❌ Usage: !massdm [message]");
                    return;
                }
                const dmText = args.join(" ");
                const friends = client.relationships.friendCache;
                let sent = 0;
                for (const [_, friend] of friends) {
                    try {
                        await friend.send(dmText);
                        sent++;
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } catch (error) {
                        console.error(`Could not send to ${friend.tag}:`, error);
                    }
                }
                message.channel.send(`✅ Message sent to ${sent} friends`);
                break;

            case "status":
                if (!args[0]) {
                    message.channel.send("❌ Usage: !status [online/idle/dnd/invisible] [emoji] [text]");
                    return;
                }
                const statusType = args[0].toLowerCase();
                const statusEmoji = args[1] || "";
                const statusText = args.slice(2).join(" ") || "";
                
                if (!["online", "idle", "dnd", "invisible"].includes(statusType)) {
                    message.channel.send("❌ Invalid status");
                    return;
                }

                await client.user.setStatus(statusType);
                if (statusText) {
                    await client.user.setActivity(statusText, { type: "CUSTOM", state: statusEmoji ? `${statusEmoji} ${statusText}` : statusText });
                }
                message.channel.send(`✅ Status updated`);
                break;

            case "game":
                const gameName = args.join(" ");
                if (gameName) {
                    await client.user.setActivity(gameName);
                    message.channel.send(`✅ Game status set to: ${gameName}`);
                } else {
                    await client.user.setActivity(null);
                    message.channel.send("✅ Game status removed");
                }
                break;

            case "help":
                let helpMessage = `**Available Commands**\n\n`;
                helpMessage += `**Message Management**\n`;
                helpMessage += `\`${prefix}edit [number] [text]\` - Edit your recent messages\n`;
                helpMessage += `\`${prefix}autoreply [message]\` - Set auto-reply for channel\n`;
                helpMessage += `\`${prefix}autoreact [emoji]\` - Toggle auto-react\n`;
                helpMessage += `\`${prefix}quote [ID]\` - Quote a message\n`;
                helpMessage += `\`${prefix}spam [number] [message]\` - Send message multiple times\n\n`;
                
                helpMessage += `**Direct Messages**\n`;
                helpMessage += `\`${prefix}dm [@user] [message]\` - Send a DM\n`;
                helpMessage += `\`${prefix}massdm [message]\` - Send DM to all friends\n\n`;
                
                helpMessage += `**Utilities**\n`;
                helpMessage += `\`${prefix}ping\` - Show latency\n`;
                helpMessage += `\`${prefix}clear [number]\` - Delete your messages\n`;
                helpMessage += `\`${prefix}ghostping [@user]\` - Ghost ping a user\n`;
                helpMessage += `\`${prefix}status [type] [emoji] [text]\` - Change your status\n`;
                
                message.channel.send(helpMessage);
                break;

            default:
                message.channel.send(`❌ Unknown command. Use ${prefix}help to see available commands.`);
        }
    } catch (error) {
        console.error("Error executing command:", error);
        message.channel.send("❌ An error occurred while executing the command.");
    }
});

// Error handling
client.on("error", (error) => {
    console.error("An error occurred:", error);
});

process.on("unhandledRejection", (error) => {
    console.error("Unhandled promise rejection:", error);
});